﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Laba1patern.ViewModels;

namespace Laba1patern
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (DataContext is MainViewModel viewModel)
            {
                // Прив'язуємо PasswordBox до ViewModel
                viewModel.LoginPasswordBox = LoginPassword;
                viewModel.RegisterPasswordBox = RegisterPassword;

                // Встановлюємо посилання на View для ViewModel
                viewModel.SetMainWindow(this);
            }
        }

        // Методи для оновлення видимості View
        public void ShowLoginView() => ShowView(LoginView);
        public void ShowRegisterView() => ShowView(RegistrationView);
        public void ShowMainMenuView() => ShowView(MainMenuView);
        public void ShowCategoryView() => ShowView(CategoryView);
        public void ShowQuizSelectionView() => ShowView(QuizSelectionView);
        public void ShowQuizView() => ShowView(QuizView);
        public void ShowResultsView() => ShowView(ResultsView);

        private void ShowView(Grid viewToShow)
        {
            // Ховаємо всі View
            LoginView.Visibility = Visibility.Collapsed;
            RegistrationView.Visibility = Visibility.Collapsed;
            MainMenuView.Visibility = Visibility.Collapsed;
            CategoryView.Visibility = Visibility.Collapsed;
            QuizSelectionView.Visibility = Visibility.Collapsed;
            QuizView.Visibility = Visibility.Collapsed;
            ResultsView.Visibility = Visibility.Collapsed;

            // Показуємо потрібне View
            viewToShow.Visibility = Visibility.Visible;
        }
    }
}
