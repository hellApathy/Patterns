﻿using Laba1patern.Interfaces;
using Laba1patern.Models;
using Laba1patern.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Laba1patern.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly IAuthenticationService _authService;
        private readonly IQuizService _quizService;
        private readonly UserService _userService;
        private readonly IQuizRepository _quizRepository;

        private User _currentUser;
        private Quiz _currentQuiz;
        private Question _currentQuestion;
        private int _currentQuestionIndex;
        private QuizResult _quizResult;
        private PasswordBox _loginPasswordBox;
        private PasswordBox _registerPasswordBox;
        private MainWindow _mainWindow;

        public MainViewModel(IAuthenticationService authService, IQuizService quizService,
                           UserService userService, IQuizRepository quizRepository)
        {
            _authService = authService;
            _quizService = quizService;
            _userService = userService;
            _quizRepository = quizRepository;

            UserAnswers = new ObservableCollection<Question>();
            InitializeCommands();
            LoadCategories();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void SetMainWindow(MainWindow mainWindow)
        {
            _mainWindow = mainWindow;
        }

        public User CurrentUser
        {
            get => _currentUser;
            set
            {
                _currentUser = value;
                OnPropertyChanged();
            }
        }

        public Quiz CurrentQuiz
        {
            get => _currentQuiz;
            set
            {
                _currentQuiz = value;
                OnPropertyChanged();
            }
        }

        public Question CurrentQuestion
        {
            get => _currentQuestion;
            set
            {
                _currentQuestion = value;
                OnPropertyChanged();
            }
        }

        public int CurrentQuestionIndex
        {
            get => _currentQuestionIndex;
            set
            {
                _currentQuestionIndex = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(CurrentQuestionNumber));
            }
        }

        public int CurrentQuestionNumber => CurrentQuestionIndex + 1;

        public QuizResult QuizResult
        {
            get => _quizResult;
            set
            {
                _quizResult = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(ResultMessage));
            }
        }

        public string ResultMessage
        {
            get
            {
                if (QuizResult == null) return "";
                var percentage = (double)QuizResult.Score / QuizResult.TotalQuestions * 100;

                if (percentage >= 90) return "Відмінно! 🎉";
                if (percentage >= 70) return "Добре! 👍";
                if (percentage >= 50) return "Задовільно 👌";
                return "Треба повчитись 📚";
            }
        }

        public int TotalQuestions => UserAnswers?.Count ?? 0;

        public ObservableCollection<Category> Categories { get; } = new ObservableCollection<Category>();
        public ObservableCollection<Quiz> Quizzes { get; } = new ObservableCollection<Quiz>();
        public ObservableCollection<Question> UserAnswers { get; } = new ObservableCollection<Question>();

        public Category SelectedCategory { get; set; }
        public Quiz SelectedQuiz { get; set; }

        public string Username { get; set; }
        public DateTime BirthDate { get; set; } = DateTime.Now.AddYears(-20);

        public PasswordBox LoginPasswordBox
        {
            get => _loginPasswordBox;
            set
            {
                _loginPasswordBox = value;
                OnPropertyChanged();
            }
        }

        public PasswordBox RegisterPasswordBox
        {
            get => _registerPasswordBox;
            set
            {
                _registerPasswordBox = value;
                OnPropertyChanged();
            }
        }

        // Команди
        public ICommand LoginCommand { get; private set; }
        public ICommand RegisterCommand { get; private set; }
        public ICommand ShowLoginCommand { get; private set; }
        public ICommand ShowRegisterCommand { get; private set; }
        public ICommand StartQuizCommand { get; private set; }
        public ICommand ShowResultsCommand { get; private set; }
        public ICommand ShowTopResultsCommand { get; private set; }
        public ICommand ShowSettingsCommand { get; private set; }
        public ICommand LogoutCommand { get; private set; }
        public ICommand ShowMainMenuCommand { get; private set; }
        public ICommand ShowCategoryCommand { get; private set; }
        public ICommand ShowQuizSelectionCommand { get; private set; }
        public ICommand StartSelectedQuizCommand { get; private set; }
        public ICommand NextQuestionCommand { get; private set; }

        private void InitializeCommands()
        {
            LoginCommand = new RelayCommand(Login);
            RegisterCommand = new RelayCommand(Register);
            ShowLoginCommand = new RelayCommand(ShowLogin);
            ShowRegisterCommand = new RelayCommand(ShowRegister);
            StartQuizCommand = new RelayCommand(ShowCategory);
            ShowResultsCommand = new RelayCommand(ShowResults);
            ShowTopResultsCommand = new RelayCommand(ShowTopResults);
            ShowSettingsCommand = new RelayCommand(ShowSettings);
            LogoutCommand = new RelayCommand(Logout);
            ShowMainMenuCommand = new RelayCommand(ShowMainMenu);
            ShowCategoryCommand = new RelayCommand(ShowCategory);
            ShowQuizSelectionCommand = new RelayCommand(ShowQuizSelection);
            StartSelectedQuizCommand = new RelayCommand(StartSelectedQuiz);
            NextQuestionCommand = new RelayCommand(NextQuestion);
        }

        private void ShowLogin()
        {
            _mainWindow?.ShowLoginView();
        }

        private void ShowRegister()
        {
            _mainWindow?.ShowRegisterView();
        }

        private void ShowMainMenu()
        {
            _mainWindow?.ShowMainMenuView();
        }

        private void ShowCategory()
        {
            _mainWindow?.ShowCategoryView();
        }

        private void ShowQuizSelection()
        {
            if (SelectedCategory == null)
            {
                MessageBox.Show("Оберіть категорію");
                return;
            }

            Quizzes.Clear();
            var quizzes = _quizService.GetQuizzesByCategory(SelectedCategory.CategoryId);
            foreach (var quiz in quizzes)
            {
                Quizzes.Add(quiz);
            }

            if (!Quizzes.Any())
            {
                MessageBox.Show("На жаль, для цієї категорії ще немає вікторин.");
                return;
            }

            _mainWindow?.ShowQuizSelectionView();
        }

        private void Login()
        {
            if (string.IsNullOrWhiteSpace(Username) || LoginPasswordBox == null || string.IsNullOrWhiteSpace(LoginPasswordBox.Password))
            {
                MessageBox.Show("Будь ласка, заповніть всі поля");
                return;
            }

            var user = _authService.Login(Username, LoginPasswordBox.Password);
            if (user != null)
            {
                CurrentUser = user;
                ClearLoginFields();
                ShowMainMenu();
            }
            else
            {
                MessageBox.Show("Невірний логін або пароль");
            }
        }

        private void Register()
        {
            if (string.IsNullOrWhiteSpace(Username) || RegisterPasswordBox == null || string.IsNullOrWhiteSpace(RegisterPasswordBox.Password))
            {
                MessageBox.Show("Будь ласка, заповніть всі поля");
                return;
            }

            var user = new User
            {
                Username = Username,
                Password = RegisterPasswordBox.Password,
                BirthDate = BirthDate
            };

            if (_authService.Register(user))
            {
                MessageBox.Show("Реєстрація успішна! Тепер увійдіть у систему.");
                ClearLoginFields();
                ShowLogin();
            }
            else
            {
                MessageBox.Show("Помилка реєстрації. Можливо, логін вже зайнятий.");
            }
        }

        private void StartSelectedQuiz()
        {
            if (SelectedQuiz == null)
            {
                MessageBox.Show("Оберіть вікторину");
                return;
            }

            CurrentQuiz = SelectedQuiz;
            UserAnswers.Clear();

            // Завантажуємо питання
            var questions = _quizRepository.GetQuestionsWithAnswers(CurrentQuiz.QuizId).ToList();
            foreach (var question in questions)
            {
                UserAnswers.Add(question);
            }

            if (!UserAnswers.Any())
            {
                MessageBox.Show("На жаль, ця вікторина ще не має питань.");
                return;
            }

            // Починаємо з першого питання
            CurrentQuestionIndex = 0;
            CurrentQuestion = UserAnswers[CurrentQuestionIndex];
            _mainWindow?.ShowQuizView();
        }

        private void NextQuestion()
        {
            if (CurrentQuestionIndex < UserAnswers.Count - 1)
            {
                CurrentQuestionIndex++;
                CurrentQuestion = UserAnswers[CurrentQuestionIndex];
            }
            else
            {
                FinishQuiz();
            }
        }

        private void FinishQuiz()
        {
            try
            {
                QuizResult = _quizService.StartQuiz(CurrentUser.UserId, CurrentQuiz.QuizId, UserAnswers.ToList());
                _mainWindow?.ShowResultsView();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при завершенні вікторини: {ex.Message}");
            }
        }

        private void ShowResults()
        {
            MessageBox.Show("Функція перегляду результатів буде реалізована в майбутньому");
        }

        private void ShowTopResults()
        {
            MessageBox.Show("Функція перегляду топ-20 буде реалізована в майбутньому");
        }

        private void ShowSettings()
        {
            MessageBox.Show("Функція налаштувань буде реалізована в майбутньому");
        }

        private void Logout()
        {
            CurrentUser = null;
            ClearCollections();
            ClearLoginFields();
            ShowLogin();
        }

        private void LoadCategories()
        {
            Categories.Clear();
            var categories = _quizService.GetAvailableCategories();
            foreach (var category in categories)
            {
                Categories.Add(category);
            }
        }

        private void ClearLoginFields()
        {
            Username = string.Empty;
            if (LoginPasswordBox != null) LoginPasswordBox.Password = string.Empty;
            if (RegisterPasswordBox != null) RegisterPasswordBox.Password = string.Empty;
            BirthDate = DateTime.Now.AddYears(-20);
            OnPropertyChanged(nameof(Username));
            OnPropertyChanged(nameof(BirthDate));
        }

        private void ClearCollections()
        {
            UserAnswers.Clear();
            Quizzes.Clear();
        }
    }
}
