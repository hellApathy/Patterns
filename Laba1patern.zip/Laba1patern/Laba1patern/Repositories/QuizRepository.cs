﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba1patern.Interfaces;
using System.Data.SqlClient;
using Laba1patern.Models;

namespace Laba1patern.Repositories
{
    public class QuizRepository : BaseRepository, IQuizRepository
    {
        public QuizRepository(string connectionString) : base(connectionString) { }

        public IEnumerable<Quiz> GetByCategory(int categoryId)
        {
            var quizzes = new List<Quiz>();
            using (var connection = GetConnection())
            {
                connection.Open();

                var query = "SELECT * FROM Quizzes WHERE CategoryId = @categoryId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@categoryId", categoryId);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            quizzes.Add(new Quiz
                            {
                                QuizId = (int)reader["QuizId"],
                                CategoryId = (int)reader["CategoryId"],
                                Title = (string)reader["Title"],
                                Description = reader["Description"] as string,
                                CreatedBy = (int)reader["CreatedBy"],
                                CreatedAt = (DateTime)reader["CreatedAt"]
                            });
                        }
                    }
                }
            }
            return quizzes;
        }

        public IEnumerable<Question> GetQuestionsWithAnswers(int quizId)
        {
            var questions = new Dictionary<int, Question>();

            using (var connection = GetConnection())
            {
                connection.Open();
                var query = @"
                    SELECT q.*, a.AnswerId, a.AnswerText, a.IsCorrect 
                    FROM Questions q 
                    LEFT JOIN Answers a ON q.QuestionId = a.QuestionId 
                    WHERE q.QuizId = @quizId 
                    ORDER BY q.QuestionId, a.AnswerId";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@quizId", quizId);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var questionId = (int)reader["QuestionId"];

                            if (!questions.ContainsKey(questionId))
                            {
                                questions[questionId] = new Question
                                {
                                    QuestionId = questionId,
                                    QuizId = (int)reader["QuizId"],
                                    QuestionText = (string)reader["QuestionText"],
                                    QuestionType = (string)reader["QuestionType"]
                                };
                            }

                            if (reader["AnswerId"] != DBNull.Value)
                            {
                                questions[questionId].Answers.Add(new Answer
                                {
                                    AnswerId = (int)reader["AnswerId"],
                                    QuestionId = questionId,
                                    AnswerText = (string)reader["AnswerText"],
                                    IsCorrect = (bool)reader["IsCorrect"]
                                });
                            }
                        }
                    }
                }
            }

            return questions.Values;
        }

        public bool SaveQuizResult(QuizResult result)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = @"
                    INSERT INTO QuizResults (UserId, QuizId, Score, TotalQuestions) 
                    VALUES (@userId, @quizId, @score, @totalQuestions)";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@userId", result.UserId);
                    command.Parameters.AddWithValue("@quizId", result.QuizId);
                    command.Parameters.AddWithValue("@score", result.Score);
                    command.Parameters.AddWithValue("@totalQuestions", result.TotalQuestions);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public IEnumerable<QuizResult> GetUserResults(int userId)
        {
            var results = new List<QuizResult>();
            using (var connection = GetConnection())
            {
                connection.Open();

                var query = @"
                    SELECT qr.*, q.Title as QuizTitle 
                    FROM QuizResults qr 
                    JOIN Quizzes q ON qr.QuizId = q.QuizId 
                    WHERE qr.UserId = @userId 
                    ORDER BY qr.CompletedAt DESC";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@userId", userId);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            results.Add(new QuizResult
                            {
                                ResultId = (int)reader["ResultId"],
                                UserId = (int)reader["UserId"],
                                QuizId = (int)reader["QuizId"],
                                Score = (int)reader["Score"],
                                TotalQuestions = (int)reader["TotalQuestions"],
                                CompletedAt = (DateTime)reader["CompletedAt"],
                                QuizTitle = (string)reader["QuizTitle"]
                            });
                        }
                    }
                }
            }
            return results;
        }

        public IEnumerable<QuizResult> GetTopResults(int quizId, int topCount = 20)
        {
            var results = new List<QuizResult>();
            using (var connection = GetConnection())
            {
                connection.Open();

                var query = @"
                    SELECT TOP (@topCount) qr.*, u.Username, q.Title as QuizTitle 
                    FROM QuizResults qr 
                    JOIN Users u ON qr.UserId = u.UserId 
                    JOIN Quizzes q ON qr.QuizId = q.QuizId 
                    WHERE qr.QuizId = @quizId 
                    ORDER BY qr.Score DESC, qr.CompletedAt ASC";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@quizId", quizId);
                    command.Parameters.AddWithValue("@topCount", topCount);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            results.Add(new QuizResult
                            {
                                ResultId = (int)reader["ResultId"],
                                UserId = (int)reader["UserId"],
                                QuizId = (int)reader["QuizId"],
                                Score = (int)reader["Score"],
                                TotalQuestions = (int)reader["TotalQuestions"],
                                CompletedAt = (DateTime)reader["CompletedAt"],
                                Username = (string)reader["Username"],
                                QuizTitle = (string)reader["QuizTitle"]
                            });
                        }
                    }
                }
            }
            return results;
        }
    }
}
