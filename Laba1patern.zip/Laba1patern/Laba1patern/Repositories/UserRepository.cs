﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba1patern.Interfaces;
using System.Data.SqlClient;
using Laba1patern.Models;

namespace Laba1patern.Repositories
{
    public class UserRepository : BaseRepository, IUserRepository
    {
        public UserRepository(string connectionString) : base(connectionString) { }

        public User GetById(int id)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = "SELECT * FROM Users WHERE UserId = @id";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    using (var reader = command.ExecuteReader())
                    {
                        return reader.Read() ? MapUser(reader) : null;
                    }
                }
            }
        }

        public User GetByUsername(string username)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = "SELECT * FROM Users WHERE Username = @username";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);

                    using (var reader = command.ExecuteReader())
                    {
                        return reader.Read() ? MapUser(reader) : null;
                    }
                }
            }
        }

        public IEnumerable<User> GetAll()
        {
            var users = new List<User>();
            using (var connection = GetConnection())
            {
                connection.Open();

                var query = "SELECT * FROM Users";
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        users.Add(MapUser(reader));
                    }
                }
            }
            return users;
        }

        public bool Add(User user)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = "INSERT INTO Users (Username, Password, BirthDate) VALUES (@username, @password, @birthdate)";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", user.Username);
                    command.Parameters.AddWithValue("@password", user.Password);
                    command.Parameters.AddWithValue("@birthdate", user.BirthDate);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool Update(User user)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = @"UPDATE Users SET Username = @username, Password = @password, 
                             BirthDate = @birthdate WHERE UserId = @userId";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", user.Username);
                    command.Parameters.AddWithValue("@password", user.Password);
                    command.Parameters.AddWithValue("@birthdate", user.BirthDate);
                    command.Parameters.AddWithValue("@userId", user.UserId);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool Delete(int id)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = "DELETE FROM Users WHERE UserId = @id";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool UsernameExists(string username)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = "SELECT COUNT(*) FROM Users WHERE Username = @Username";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        public bool UpdatePassword(int userId, string newPassword)
        {
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    var query = "UPDATE Users SET Password = @NewPassword WHERE UserId = @UserId";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@NewPassword", newPassword);
                        command.Parameters.AddWithValue("@UserId", userId);
                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0; // Возвращает true если пароль обновлен
                    }
                }
            }
            catch
            {
                return false; // Возвращает false при ошибке
            }
        }

        public bool ChangePassword(int userId, string newPassword)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = "UPDATE Users SET Password = @password WHERE UserId = @userId";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@password", newPassword);
                    command.Parameters.AddWithValue("@userId", userId);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        private User MapUser(SqlDataReader reader)
        {
            return new User
            {
                UserId = (int)reader["UserId"],
                Username = (string)reader["Username"],
                Password = (string)reader["Password"],
                BirthDate = (DateTime)reader["BirthDate"],
                CreatedAt = (DateTime)reader["CreatedAt"]
            };
        }
    }
}