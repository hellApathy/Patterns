﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba1patern.Interfaces;
using System.Data.SqlClient;
using Laba1patern.Models;

namespace Laba1patern.Repositories
{
    public class CategoryRepository : BaseRepository, ICategoryRepository
    {
        public CategoryRepository(string connectionString) : base(connectionString) { }

        public Category GetById(int id)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = "SELECT * FROM Categories WHERE CategoryId = @id";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    using (var reader = command.ExecuteReader())
                    {
                        return reader.Read() ? MapCategory(reader) : null;
                    }
                }
            }
        }

        public IEnumerable<Category> GetAll()
        {
            var categories = new List<Category>();
            using (var connection = GetConnection())
            {
                connection.Open();

                var query = "SELECT * FROM Categories";
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(MapCategory(reader));
                    }
                }
            }
            return categories;
        }

        public bool Add(Category category)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = "INSERT INTO Categories (Name, Description) VALUES (@name, @description)";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@name", category.Name);
                    command.Parameters.AddWithValue("@description", category.Description ?? (object)DBNull.Value);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool Update(Category category)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = "UPDATE Categories SET Name = @name, Description = @description WHERE CategoryId = @id";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@name", category.Name);
                    command.Parameters.AddWithValue("@description", category.Description ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@id", category.CategoryId);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool Delete(int id)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var query = "DELETE FROM Categories WHERE CategoryId = @id";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        private Category MapCategory(SqlDataReader reader)
        {
            return new Category
            {
                CategoryId = (int)reader["CategoryId"],
                Name = (string)reader["Name"],
                Description = reader["Description"] as string
            };
        }
    }
}

