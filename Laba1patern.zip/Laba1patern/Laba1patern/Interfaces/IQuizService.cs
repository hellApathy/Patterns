﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba1patern.Models;

namespace Laba1patern.Interfaces
{
    public interface IQuizService
    {
        QuizResult StartQuiz(int userId, int quizId, List<Question> userAnswers);
        IEnumerable<Category> GetAvailableCategories();
        IEnumerable<Quiz> GetQuizzesByCategory(int categoryId);
    }
}
