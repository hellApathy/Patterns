﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba1patern.Models;

namespace Laba1patern.Interfaces
{
    public interface IAuthenticationService
    {
        User Login(string username, string password);
        bool Register(User user);
        bool ValidateUser(string username, string password);
    }
}
