﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba1patern.Models;

namespace Laba1patern.Interfaces
{
    public interface IRepository<T> where T : class
    {
        T GetById(int id);
        IEnumerable<T> GetAll();
        bool Add(T entity);
        bool Update(T entity);
        bool Delete(int id);
    }

    public interface IUserRepository : IRepository<User>
    {
        User GetByUsername(string username);
        bool UsernameExists(string username);
        bool UpdatePassword(int userId, string newPassword);
    }

    public interface IQuizRepository
    {
        IEnumerable<Quiz> GetByCategory(int categoryId);
        IEnumerable<Question> GetQuestionsWithAnswers(int quizId);
        bool SaveQuizResult(QuizResult result);
        IEnumerable<QuizResult> GetUserResults(int userId);
        IEnumerable<QuizResult> GetTopResults(int quizId, int topCount = 20);
    }

    public interface ICategoryRepository : IRepository<Category> { }
}

