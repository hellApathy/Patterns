﻿using Laba1patern.Interfaces;
using Laba1patern.Services;
using Laba1patern.ViewModels;
using Laba1patern.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Laba1patern
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Створюємо репозиторії та сервіси вручну
            const string connectionString = @"Server=localhost\SQLEXPRESS;Database=QuizApp1;Integrated Security=true;";

            var userRepository = new UserRepository(connectionString);
            var categoryRepository = new CategoryRepository(connectionString);
            var quizRepository = new QuizRepository(connectionString);

            var authService = new AuthenticationService(userRepository);
            var quizService = new QuizService(quizRepository, categoryRepository);
            var userService = new UserService(userRepository);

            // Створюємо MainViewModel з залежностями
            var mainViewModel = new MainViewModel(authService, quizService, userService, quizRepository);

            // Створюємо головне вікно
            var mainWindow = new MainWindow();
            mainWindow.DataContext = mainViewModel;
            mainWindow.Show();
        }
    }
}
