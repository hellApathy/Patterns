﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba1patern.Interfaces;
using System.Data.SqlClient;
using Laba1patern.Models;


namespace Laba1patern.Services
{
    public class QuizService : IQuizService
    {
        private readonly IQuizRepository _quizRepository;
        private readonly ICategoryRepository _categoryRepository;

        public QuizService(IQuizRepository quizRepository, ICategoryRepository categoryRepository)
        {
            _quizRepository = quizRepository ?? throw new ArgumentNullException(nameof(quizRepository));
            _categoryRepository = categoryRepository ?? throw new ArgumentNullException(nameof(categoryRepository));
        }

        public IEnumerable<Category> GetAvailableCategories()
        {
            try
            {
                return _categoryRepository.GetAll();
            }
            catch (Exception ex)
            {
                // Логування помилки
                System.Diagnostics.Debug.WriteLine($"Error getting categories: {ex.Message}");
                return new List<Category>();
            }
        }

        public IEnumerable<Quiz> GetQuizzesByCategory(int categoryId)
        {
            if (categoryId <= 0)
                throw new ArgumentException("Invalid category ID", nameof(categoryId));

            try
            {
                return _quizRepository.GetByCategory(categoryId);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error getting quizzes for category {categoryId}: {ex.Message}");
                return new List<Quiz>();
            }
        }

        public QuizResult StartQuiz(int userId, int quizId, List<Question> userAnswers)
        {
            // Валідація вхідних параметрів
            if (userId <= 0)
                throw new ArgumentException("Invalid user ID", nameof(userId));

            if (quizId <= 0)
                throw new ArgumentException("Invalid quiz ID", nameof(quizId));

            if (userAnswers == null)
                throw new ArgumentNullException(nameof(userAnswers));

            try
            {
                // Отримуємо оригінальні питання з бази даних
                var originalQuestions = _quizRepository.GetQuestionsWithAnswers(quizId).ToList();

                if (!originalQuestions.Any())
                    throw new InvalidOperationException("No questions found for this quiz");

                // Розрахунок результату
                var score = CalculateScore(originalQuestions, userAnswers);

                // Створення результату
                var result = new QuizResult
                {
                    UserId = userId,
                    QuizId = quizId,
                    Score = score,
                    TotalQuestions = originalQuestions.Count,
                    CompletedAt = DateTime.Now
                };

                // Збереження результату
                var saved = _quizRepository.SaveQuizResult(result);
                if (!saved)
                    throw new InvalidOperationException("Failed to save quiz result");

                return result;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error starting quiz: {ex.Message}");
                throw;
            }
        }

        private int CalculateScore(List<Question> originalQuestions, List<Question> userAnswers)
        {
            int score = 0;

            foreach (var originalQuestion in originalQuestions)
            {
                var userQuestion = userAnswers.FirstOrDefault(q => q.QuestionId == originalQuestion.QuestionId);
                if (userQuestion == null)
                    continue;

                if (IsAnswerCorrect(originalQuestion, userQuestion))
                {
                    score++;
                }
            }

            return score;
        }

        private bool IsAnswerCorrect(Question original, Question userAnswer)
        {
            // Отримуємо правильні відповіді
            var correctAnswers = original.Answers.Where(a => a.IsCorrect).ToList();

            // Отримуємо відповіді користувача
            var userSelected = userAnswer.Answers.Where(a => a.IsSelected).ToList();

            // Для питань з однією правильною відповіддю
            if (original.QuestionType == "Single")
            {
                if (userSelected.Count != 1)
                    return false;

                return correctAnswers.Any(correct => correct.AnswerId == userSelected[0].AnswerId);
            }
            // Для питань з кількома правильними відповідями
            else if (original.QuestionType == "Multiple")
            {
                if (userSelected.Count != correctAnswers.Count)
                    return false;

                // Перевіряємо, чи всі обрані відповіді правильні
                foreach (var userSelectedAnswer in userSelected)
                {
                    if (!correctAnswers.Any(correct => correct.AnswerId == userSelectedAnswer.AnswerId))
                        return false;
                }

                return true;
            }

            return false;
        }
    }
}
