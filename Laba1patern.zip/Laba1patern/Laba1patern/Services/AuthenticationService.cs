﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba1patern.Interfaces;
using System.Data.SqlClient;
using Laba1patern.Models;

namespace Laba1patern.Services
{
    public class AuthenticationService : IAuthenticationService
    {
        private readonly IUserRepository _userRepository;

        public AuthenticationService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public User Login(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                return null;

            var user = _userRepository.GetByUsername(username);
            return user != null && user.Password == password ? user : null;
        }

        public bool Register(User user)
        {
            if (user == null || string.IsNullOrWhiteSpace(user.Username) || string.IsNullOrWhiteSpace(user.Password))
                return false;

            if (_userRepository.UsernameExists(user.Username))
                return false;

            return _userRepository.Add(user);
        }

        public bool ValidateUser(string username, string password)
        {
            var user = _userRepository.GetByUsername(username);
            return user != null && user.Password == password;
        }
    }
}
