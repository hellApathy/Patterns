﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba1patern.Interfaces;
using Laba1patern.Models;

namespace Laba1patern.Services
{
    public class UserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public bool UpdatePassword(int userId, string newPassword)
        {
            if (string.IsNullOrWhiteSpace(newPassword))
                return false;

            return _userRepository.UpdatePassword(userId, newPassword);
        }

        public bool UpdateUser(User user)
        {
            if (user == null)
                return false;

            return _userRepository.Update(user);
        }

        public User GetUser(int userId)
        {
            return _userRepository.GetById(userId);
        }
    }
}
